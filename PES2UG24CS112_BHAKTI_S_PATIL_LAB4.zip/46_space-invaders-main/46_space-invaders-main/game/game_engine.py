import pygame
import random
import os
from .player import Player
from .enemy import EnemyGrid
from .bullet import Bullet

# Game Engine

WHITE = (255, 255, 255)
GREEN = (0, 200, 0)
RED = (220, 60, 60)

DIFFICULTIES = {
    "Easy": {
        "speed": 1.0,
        "fire_chance": 0.001
    },
    "Medium": {
        "speed": 1.5,
        "fire_chance": 0.003
    },
    "Hard": {
        "speed": 3.0,
        "fire_chance": 0.006
    }
}


class GameEngine:
    def __init__(self, width, height):
        self.width = width
        self.height = height

        # Task 3: Default difficulty
        self.difficulty = "Medium"

        self.player = Player(width // 2 - 20, height - 50, 40, 20)

        self.enemy_grid = EnemyGrid(
            width,
            speed=DIFFICULTIES[self.difficulty]["speed"]
        )

        self.player_bullets = []
        self.enemy_bullets = []
        self._shoot_cooldown = 0

        self.enemy_fire_chance = (
            DIFFICULTIES[self.difficulty]["fire_chance"]
        )

        self.score = 0
        self.font = pygame.font.SysFont("Arial", 30)
        self.game_over = False
        self._game_over_logged = False

        # ---------------------------------------------------------
        # Task 4: Sound initialization
        # ---------------------------------------------------------
        self.sound_enabled = False
        self.shoot_sound = None
        self.enemy_destroyed_sound = None
        self.game_over_sound = None
        self._game_over_sound_played = False

        try:
            if not pygame.mixer.get_init():
                pygame.mixer.init()

            sound_dir = os.path.join(
                os.path.dirname(__file__),
                "sounds"
            )

            self.shoot_sound = pygame.mixer.Sound(
                os.path.join(sound_dir, "player_shoot.wav")
            )

            self.enemy_destroyed_sound = pygame.mixer.Sound(
                os.path.join(sound_dir, "enemy_destroyed.wav")
            )

            self.game_over_sound = pygame.mixer.Sound(
                os.path.join(sound_dir, "game_over.wav")
            )

            self.sound_enabled = True

        except (pygame.error, FileNotFoundError, OSError):
            # Audio is optional. The game continues normally
            # if the mixer or sound files are unavailable.
            self.sound_enabled = False

    def set_difficulty(self, difficulty):
        if difficulty in DIFFICULTIES:
            self.difficulty = difficulty

    def reset_game(self):
        """
        Reset the game completely while keeping the
        currently selected difficulty.
        """

        difficulty_settings = DIFFICULTIES[self.difficulty]

        # Reset score
        self.score = 0

        # Reset player
        self.player = Player(
            self.width // 2 - 20,
            self.height - 50,
            40,
            20
        )

        # Reset enemies using selected difficulty
        self.enemy_grid = EnemyGrid(
            self.width,
            speed=difficulty_settings["speed"]
        )

        # Clear bullets
        self.player_bullets = []
        self.enemy_bullets = []

        # Reset game state
        self.game_over = False
        self._game_over_logged = False

        # Reset shooting cooldown
        self._shoot_cooldown = 0

        # Apply selected difficulty
        self.enemy_fire_chance = (
            difficulty_settings["fire_chance"]
        )

        # Task 4: Allow Game Over sound to play again
        # when this new game eventually ends.
        self._game_over_sound_played = False

    def handle_event(self, event):
        if event.type == pygame.KEYDOWN:

            # Task 3: Controls available during Game Over
            if self.game_over:

                # Select Easy
                if event.key == pygame.K_e:
                    self.set_difficulty("Easy")

                # Select Medium
                elif event.key == pygame.K_m:
                    self.set_difficulty("Medium")

                # Select Hard
                elif event.key == pygame.K_h:
                    self.set_difficulty("Hard")

                # Play Again using selected difficulty
                elif event.key == pygame.K_p:
                    self.reset_game()

                # Exit
                elif event.key == pygame.K_ESCAPE:
                    pygame.quit()
                    raise SystemExit

                return

            # Existing SPACE shooting
            if event.key == pygame.K_SPACE:
                if self._shoot_cooldown <= 0:
                    bullet_x = self.player.center_x() - 2

                    self.player_bullets.append(
                        Bullet(
                            bullet_x,
                            self.player.y,
                            direction=-1
                        )
                    )

                    self._shoot_cooldown = 15

                    # Task 4: Player shooting sound
                    if self.sound_enabled and self.shoot_sound:
                        self.shoot_sound.play()

    def handle_input(self):
        # Do not process normal movement after Game Over
        if self.game_over:
            return

        keys = pygame.key.get_pressed()

        if keys[pygame.K_LEFT] or keys[pygame.K_a]:
            self.player.move(-self.player.speed, self.width)

        if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
            self.player.move(self.player.speed, self.width)

    def update(self):
        if self.game_over:
            return

        if self._shoot_cooldown > 0:
            self._shoot_cooldown -= 1

        self.enemy_grid.move()

        for enemy in self.enemy_grid.alive_enemies():
            if random.random() < self.enemy_fire_chance:
                bullet_x = enemy.x + enemy.width // 2

                self.enemy_bullets.append(
                    Bullet(
                        bullet_x,
                        enemy.y + enemy.height,
                        direction=1
                    )
                )

        for bullet in self.player_bullets:
            bullet.move()

        for bullet in self.enemy_bullets:
            bullet.move()

        self.player_bullets = [
            b for b in self.player_bullets
            if not b.off_screen(self.height)
        ]

        self.enemy_bullets = [
            b for b in self.enemy_bullets
            if not b.off_screen(self.height)
        ]

        # ---------------------------------------------------------
        # Task 1 fix:
        # Keep this exactly as implemented.
        # ---------------------------------------------------------
        for bullet in self.player_bullets.copy():
            for enemy in self.enemy_grid.alive_enemies():
                if bullet.rect().colliderect(enemy.rect()):
                    enemy.alive = False
                    self.player_bullets.remove(bullet)
                    self.score += 1

                    # Task 4: Enemy destroyed sound
                    if (
                        self.sound_enabled
                        and self.enemy_destroyed_sound
                    ):
                        self.enemy_destroyed_sound.play()

                    break

        # Enemy bullet hits player
        for bullet in self.enemy_bullets:
            if bullet.rect().colliderect(self.player.rect()):
                self.game_over = True
                break

        # Enemies reach bottom
        if self.enemy_grid.reached_bottom(self.player.y):
            self.game_over = True

        # ---------------------------------------------------------
        # Task 4: Game Over sound
        #
        # This runs only once when game_over first becomes True.
        # ---------------------------------------------------------
        if (
            self.game_over
            and not self._game_over_sound_played
        ):
            if self.sound_enabled and self.game_over_sound:
                self.game_over_sound.play()

            self._game_over_sound_played = True

    def render(self, screen):
        pygame.draw.rect(
            screen,
            GREEN,
            self.player.rect()
        )

        for enemy in self.enemy_grid.alive_enemies():
            pygame.draw.rect(
                screen,
                WHITE,
                enemy.rect()
            )

        for bullet in self.player_bullets:
            pygame.draw.rect(
                screen,
                WHITE,
                bullet.rect()
            )

        for bullet in self.enemy_bullets:
            pygame.draw.rect(
                screen,
                RED,
                bullet.rect()
            )

        score_text = self.font.render(
            f"Score: {self.score}",
            True,
            WHITE
        )

        screen.blit(score_text, (10, 10))

        # Existing console message
        if self.game_over and not getattr(
            self,
            "_game_over_logged",
            False
        ):
            print(
                "Game over! Final score:",
                self.score
            )

            self._game_over_logged = True

        # ---------------------------------------------------------
        # Task 2 + Task 3:
        # Graphical Game Over screen
        # ---------------------------------------------------------
        if self.game_over:
            game_over_font = pygame.font.Font(None, 64)
            final_score_font = pygame.font.Font(None, 36)
            option_font = pygame.font.Font(None, 28)

            game_over_text = game_over_font.render(
                "GAME OVER",
                True,
                WHITE
            )

            final_score_text = final_score_font.render(
                f"Final Score: {self.score}",
                True,
                WHITE
            )

            play_exit_text = option_font.render(
                "P: Play Again    ESC: Exit",
                True,
                WHITE
            )

            difficulty_text = option_font.render(
                "E: Easy    M: Medium    H: Hard",
                True,
                WHITE
            )

            selected_difficulty_text = option_font.render(
                f"Selected Difficulty: {self.difficulty}",
                True,
                WHITE
            )

            game_over_rect = game_over_text.get_rect(
                center=(
                    self.width // 2,
                    self.height // 2 - 100
                )
            )

            final_score_rect = final_score_text.get_rect(
                center=(
                    self.width // 2,
                    self.height // 2 - 50
                )
            )

            play_exit_rect = play_exit_text.get_rect(
                center=(
                    self.width // 2,
                    self.height // 2 + 10
                )
            )

            difficulty_rect = difficulty_text.get_rect(
                center=(
                    self.width // 2,
                    self.height // 2 + 50
                )
            )

            selected_difficulty_rect = (
                selected_difficulty_text.get_rect(
                    center=(
                        self.width // 2,
                        self.height // 2 + 90
                    )
                )
            )

            screen.blit(
                game_over_text,
                game_over_rect
            )

            screen.blit(
                final_score_text,
                final_score_rect
            )

            screen.blit(
                play_exit_text,
                play_exit_rect
            )

            screen.blit(
                difficulty_text,
                difficulty_rect
            )

            screen.blit(
                selected_difficulty_text,
                selected_difficulty_rect
            )